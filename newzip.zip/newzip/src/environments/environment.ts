export const environment = {
  production: false,

  dialogflow: {
    angularBot: '4980633efaf1426d9b96b56053794a05'
  }
};
